package com.example.difusioncultural;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.example.difusioncultural.Tabs.TabOne;
import com.example.difusioncultural.Tabs.TabThree;
import com.example.difusioncultural.Tabs.TabTwo;

public class PageAdapter extends FragmentStatePagerAdapter {

    int countTab;

    public PageAdapter(FragmentManager fm, int countTab) {
        super(fm);
        this.countTab = countTab;
    }

    @Override
    public Fragment getItem(int i) {

        switch (i){
            case 1:
                TabOne tabOne = new TabOne();
                return tabOne;
            case 2:
                TabTwo tabTwo = new TabTwo();
                return tabTwo;
            case 3:
                TabThree tabThree = new TabThree();
                return tabThree;

                default:
                    return null;
        }

    }

    @Override
    public int getCount() {
        return countTab;
    }
}
